#include<ros/ros.h> 
#include<std_msgs/Float64.h> 

#include<problem_sheet2/SinWaveMsg.h>

//using namespace std;

int main(int argc, char **argv) {
	ros::init(argc, argv, "sin_srv_client"); //name this node  
	ros::NodeHandle nh; // node handle 
	ros::ServiceClient client = nh.serviceClient<problem_sheet2::SinWaveMsg>("sin_inputs");

	problem_sheet2::SinWaveMsg sr;
	
	double amplitude;
	double frequency;
	
	while (ros::ok()){
		std::cout << std::endl;
		std::cout << "Enter the desired sin wave amplitude: ";
		std::cin >> amplitude;

		std::cout << std::endl << "Enter the desired sin wave frequency: ";
		std::cin >> frequency;
		
		sr.request.amplitude = amplitude;
		sr.request.frequency = frequency;
		
		if (client.call(sr)) {
			if(sr.response.recieved = true){
				ROS_INFO("Succesful iteration");
			
			}
			else{
			ROS_ERROR("something has gone wrong"); //This should never happen
			return 1;
			}
		}


	}
	return 0;
}
